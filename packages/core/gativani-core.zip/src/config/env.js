import dotenv from "dotenv";

dotenv.config();

function int(name, fallback) {
  const raw = process.env[name];
  if (raw === undefined || raw === "") return fallback;
  const n = Number.parseInt(raw, 10);
  return Number.isFinite(n) ? n : fallback;
}

function bool(name, fallback = false) {
  const raw = process.env[name];
  if (raw === undefined || raw === "") return fallback;
  return ["1", "true", "yes", "on"].includes(String(raw).toLowerCase());
}

export const env = {
  port: int("PORT", 8787),
  nodeEnv: process.env.NODE_ENV || "development",
  geminiApiKey: process.env.GEMINI_API_KEY || "",
  geminiModel: process.env.GEMINI_MODEL || "gemini-2.0-flash",
  tierMaxPages: {
    free: int("TIER_FREE_MAX_PAGES", 5),
    standard: int("TIER_STANDARD_MAX_PAGES", 50),
    premium: int("TIER_PREMIUM_MAX_PAGES", 500),
  },
  trustClientTierHeaders: bool("TRUST_CLIENT_TIER_HEADERS", false),
};

export function assertGeminiConfigured() {
  if (!env.geminiApiKey) {
    throw new Error("GEMINI_API_KEY is required to call Gemini.");
  }
}
