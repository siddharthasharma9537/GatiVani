import express from "express";
import multer from "multer";
import { maxPagesForTier } from "../lib/tiers.js";
import { extractPdfTextByPageCap } from "../lib/pdfExtract.js";
import { generateWithGemini } from "../services/gemini.js";
import { requireActiveSubscription } from "../middleware/subscription.js";

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 25 * 1024 * 1024, files: 1 },
});

export const documentsRouter = express.Router();

documentsRouter.post(
  "/process",
  requireActiveSubscription,
  upload.single("document"),
  async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "missing_file", message: 'Expected multipart field "document".' });
      }

      const { tier, active } = req.subscription;
      const cap = maxPagesForTier(tier);

      const mime = req.file.mimetype || "";
      const originalName = req.file.originalname || "upload";

      let totalPages = 1;
      let processedPages = 1;
      let extractedText = "";

      // Attempt standard layout extraction first
      if (mime === "application/pdf" || originalName.toLowerCase().endsWith(".pdf")) {
        try {
          const extracted = await extractPdfTextByPageCap(req.file.buffer, cap);
          totalPages = extracted.totalPages;
          processedPages = extracted.processedPages;
          extractedText = extracted.text;
        } catch (parseErr) {
          console.warn("[documents/process] Primary text vector parse skipped, switching to multimodal container routing.");
        }
      } else if (mime === "text/plain" || originalName.toLowerCase().endsWith(".txt")) {
        extractedText = req.file.buffer.toString("utf8");
      }

      const cleanText = extractedText ? extractedText.replace(/\[Image\s*\d+\]/gi, "").replace(/\s+/g, " ").trim() : "";
      
      let summary = "";

      // 🛠️ THE SMART MULTIMODAL SWITCH:
      // If a text vector exists, pass that string. Otherwise, pass the raw file buffer directly to Gemini Vision!
      if (cleanText.length >= 5) {
        console.log(`[process] Processing document via Standard Text Layer: ${originalName}`);
        summary = await generateWithGemini({ text: cleanText, tier });
      } else {
        console.log(`[process] Text empty or custom-encoded. Engaging Multimodal Vision Core for: ${originalName}`);
        summary = await generateWithGemini({
          text: "",
          buffer: req.file.buffer,
          mimeType: mime || "application/pdf",
          tier
        });
      }

      const truncated = totalPages > processedPages;

      return res.json({
        ok: true,
        subscription: { tier, active },
        limits: { maxPages: cap, totalPages, processedPages, truncated },
        model: "gemini-2.5-flash",
        summary,
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : "Unknown error";
      console.error("[documents/process]", err);
      return res.status(500).json({ error: "process_failed", message });
    }
  }
);