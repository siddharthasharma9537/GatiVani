import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const apiKey = process.env.GEMINI_API_KEY;
if (!apiKey) {
  console.error('[gemini-service] Warning: GEMINI_API_KEY is not defined in env.');
}

const ai = new GoogleGenAI({ apiKey: apiKey });

/**
 * Robust Multimodal News Handler & Telugu Script Formatter
 * Supports clean string arrays or direct image/document buffer buffers.
 */
export async function generateWithGemini(params) {
  try {
    const { text, buffer, mimeType } = params;
    
    const systemInstruction = `
      You are an expert Telugu news broadcast script editor for GatiVani.
      Your job is to transform raw newspaper contents into an audio-optimized conversational script.
      Rules:
      1. Read down vertical column layers sequentially in natural reading order. Do not merge separate vertical textual blocks horizontally.
      2. Convert shorthand symbols, numbers, and financial indicators to fully spelled spoken Telugu text (e.g., convert '2026' to 'రెండు వేల ఇరవై ఆరు', '₹' to 'రూపాయలు').
      3. Clean text flows, correct scanning artifacts, and maintain a high-engagement broadcast style.
      4. Output ONLY the resulting clean Telugu text. Do not append any English meta-commentary or introductory conversational filler.
    `;

    let contentsPayload = [];

    // If a clean character vector exists, use it directly
    if (text && text.trim().length > 0) {
      contentsPayload.push(text);
    } 
    // Fallback: If no text was extracted, pass the file buffer directly as an inline data matrix (Multimodal)
    else if (buffer) {
      contentsPayload.push({
        inlineData: {
          data: buffer.toString('base64'),
          mimeType: mimeType || 'application/pdf'
        }
      });
      // Append a explicit vision extraction guideline request
      contentsPayload.push("Analyze this regional newspaper page carefully. Perform an accurate layout extraction and read column content top-to-bottom sequentially.");
    } else {
      throw new Error('No readable text or valid file buffer payload provided to the Gemini service handler.');
    }

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: contentsPayload,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.3
      }
    });

    if (!response || !response.text) {
      throw new Error('Google Gemini API returned an empty content generation framework output.');
    }

    return response.text;
  } catch (error) {
    console.error('[gemini-service] Generation Failed:', error);
    throw error;
  }
}