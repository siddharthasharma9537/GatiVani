import express from "express";
import cors from "cors";
import helmet from "helmet";
import { env } from "./config/env.js";
import { subscriptionContext } from "./middleware/subscription.js";
import { documentsRouter } from "./routes/documents.js";

const app = express();

app.set("trust proxy", 1);
app.disable("x-powered-by");
app.use(
  helmet({
    crossOriginResourcePolicy: { policy: "cross-origin" },
  }),
);
app.use(
  cors({
    origin: true,
    maxAge: 86_400,
  }),
);
app.use(express.json({ limit: "1mb" }));
app.use(subscriptionContext);

app.get("/health", (_req, res) => {
  res.json({
    ok: true,
    service: "voxnews-node-core",
    env: env.nodeEnv,
    trustClientTierHeaders: env.trustClientTierHeaders,
  });
});

app.use("/api/documents", documentsRouter);

app.use((_req, res) => {
  res.status(404).json({ error: "not_found" });
});

app.listen(env.port, () => {
  console.log(`[voxnews-node-core] listening on port ${env.port}`);
});
